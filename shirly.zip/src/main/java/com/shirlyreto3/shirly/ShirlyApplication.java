package com.shirlyreto3.shirly;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ShirlyApplication {

	public static void main(String[] args) {
		SpringApplication.run(ShirlyApplication.class, args);
	}

}
