package com.shirlyreto3.shirly;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ShirlyApplicationTests {

	@Test
	void contextLoads() {
	}

}
